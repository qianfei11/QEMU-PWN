# Description

Beat me again, plz!

# Docker

## Build

`docker build . -t d3dev`

## Run

`docker run -d -p "0.0.0.0:5555:5555" -h "d3dev" --name="d3dev" d3dev`

## Shell

`nc 127.0.0.1 5555`

# Attention

Each team uses its own container and has its own flag, please do not communicate with each other, do not launch DoS attacks on the server.

