#!/bin/sh
./qemu-system-x86_64 \
	-L ./dependences \
	-initrd ./rootfs.cpio \
	-kernel ./vmlinuz-4.13.0-38-generic \
	-append 'console=ttyS0 root=/dev/ram oops=panic panic=1' \
	-m 56M --nographic \
	-device ctf-scsi,id=bus0 \
	-drive file=test.img,if=none,id=d0 \
	-device scsi-disk,drive=d0,bus=bus0.0

