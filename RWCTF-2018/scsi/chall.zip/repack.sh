#!/bin/sh
cp exploit.c rootfs-extracted
cp pcimem.c rootfs-extracted
cd rootfs-extracted && cpio -i -F rootfs.cpio 2>/dev/null
musl-gcc -static -Os exploit.c -o bin/exploit
musl-gcc -static -Os pcimem.c -o bin/pcimem
cd scsi_test
make
cd ..
mv scsi_test/scsi_test ./bin/
find . | cpio --create --format='newc' > ../rootfs.cpio
