./qemu-system-x86_64 -display none -machine accel=qtest -m 512M -device qwb -nodefaults -monitor none -qtest stdio
