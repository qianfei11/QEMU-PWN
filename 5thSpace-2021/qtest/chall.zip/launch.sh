#!/bin/sh

timeout -s SIGKILL 120s ./qemu-system-x86_64  -display  none -machine  accel=qtest -m  512M -device ctf -nodefaults -monitor  none -qtest  stdio
